#define _MAIN_TASK_DISABLE_

#define _TASK_1_ 1
#define _TASK_2_ 1

#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetSysTime.h>
#include <GetSysTime.h>
#include <SetMotor.h>
#include <SetMotorCode.h>
#include <GetMotorCode.h>
#include <GetTraceV2I2C.h>
#include <SetAICamData.h>
#include <SetInBeep.h>
#include <GetData.h>
#include <SetData.h>
#include <SetWaitForTime.h>
#include <GetTouchScreen.h>
#include <SetLCDDot.h>
#include <SetDisplayString.h>
#include <SetDisplayVariable.h>
#include <SetFontSize.h>
#include <SetMagneticServoCodeMotor.h>
#include <SetMagneticServoWaitForDegree.h>
#include <SetMagneticServoEncoder.h>
#include <SetAHRS.h>
#include <GetAHRS.h>
#include <SetTraceV2BeepI2C.h>
#include <SetTraceV2PercentI2C.h>
#include <SetAICamLED.h>
#include <SetAICamData.h>
#include <SetWaitForAICamData.h>
#include <GetAICamData.h>
#include <SetWaitForAngle.h>
#include <SetMotorServo.h>
#include <SetMagneticServoDegreeSpeed.h>
#include <GetLeftButton.h>
#include <GetRightButton.h>
#include <SetLCDClear.h>

#define LIMIT( x,min,max ) ( (x) < (min)  ? (min) : ( (x) > (max) ? (max) : (x) ) )      //�޷�

/*��ѧӲ���ӿ�*/

#define fl  _M2_
#define fr  _M4_
#define bl  _M1_
#define br  _M3_
#define rotate  _P3_            //ת��
#define swing  _P6_            //���֣����°�Ϊ���������򲻶ԣ��ڿ��������޸�
#define trace  _P4_              //Ѱ�����ӿ�
#define ahrs  _P2_              //�����ǽӿ�
#define cam  _P8_           //����ͷ�ӿڣ����ֻ��p8

#define dt 30                  //����ʱ��

#define lcx 48.0             //���Ȼ��㣬��λ����
#define lcy 45.0             //���Ȼ��㣬��λ����
#define ac 11.5               //�ǶȻ��㣬��λ��

int sp1;       //�ƶ��ٶȣ��洢������
int sp2;       //�ȶ��ٶȣ��洢������
int test1;    //������
int test2;    //������
int test3;    //������
int test4;    //������
int test5;    //������
int test6;    //������
int test7;    //������

int mxmax = 2180;
int mxmin = -6295;
int mymax = 5122;
int mymin = -3480;
int comp0 = 0;
int compx;
int compy;
int compz;

int yaw;
int yaw0 = 0;

unsigned int S0[7];               //���ԭʼ����
unsigned int S[7];                  //�������
int SL;                                    //�ڰ���ͨ��
long SL_Ent;                          //ͨ������ʱ��ת������ֵ
unsigned char count;            //ѹ��ͨ������
int mode = 0;                         //����ģʽ������Ϊ0������Ϊ1                      

typedef volatile struct     //����ṹ���������
{
    float desired;                     
    float prevError;  
    float integ;  
    float deriv;	
    float kp;          
    float ki;           
    float kd;           
    float measured;
    float pidout;
}PidObject;

PidObject pidgray;        //����ṹ�����pidgray���Ҷ�λ��
PidObject pidEnt;         //����ṹ�����pidRateZ��������ת��ֵ
PidObject pidaround;        

int getBit(unsigned int ch, unsigned char bit);      //���λ����
void pd(void);                                                         //�����                    

long En_x(void);                                                   //�����ƶ�����ֵ������Ϊ��
long En_y(void);                                                    //ǰ���ƶ�����ֵ����ǰΪ��                                       
long En_z(void);                                                    //ת������ֵ����ʱ��Ϊ��
void En0(void);                                                        //����������

int angle_d(int angle);                                           //��õ�ǰ�Ƕ���ָ���Ƕ�֮����ڽǶȿ���

void mydriver(int spx, int spy, int turn);                 //�������    
void curve(int speed);                                            //Ѳ�ߣ������ѭ������                

/**********Ѳ�ߺ������ٶȺ;��붼ֻȡ��ֵ*********/

void drop(int x, int y, int speed, int error);               //x��y��ʾ����ڻ����˵����꣬speedС���ƶ��ٶȣ�error����
    
void C_D(int speed, long dist, int error);                           //������ǰ�ƶ�ָ�����룬speed��dist��Ϊ��
void C_L(int speed);                                                          //�ߵ���ת·�ڣ�speedΪ��
void C_R(int speed);                                                         //�ߵ���ת·�ڣ�speedΪ��
void C_LR(int speed);                                                       //�ߵ���ɫ
void C_A(int speed, int angle, int error);                         //�ߵ�ָ���Ƕ�
void C_B(int speed);                                                        //�ߵ��ϰ���

/******ԭ��ת��������turnת���ٶ�ֻȡ��ֵ�������������ٶ�*******/
void T_I(int speed, int angle, int error);                              //�ӵ�ǰ����ʼת��ָ����ԽǶȣ�����������Χ-1800~1800����λΪ0.1��
void T_A(int speed, int angle, int error);                             //ת��ָ�����ԽǶȣ���Χ0~3599����λΪ0.1�� 

void T_L(int speed);
void T_R(int speed);

void alignment(void);                  //�ڰ��߶���
void center(int speed);                //�м���ѹ��

void camtest(int cmd1, int cmd2);                           //����ͷ����

void vp(int x, int y);                                                 //�Ӿ���λ

void start(void);                                                      //��ʼ
void stop(void);                                                       //ֹͣ����ʾ��ʱ�������ڵ���
void program1(void);                                               //������򣬵���Ļ����
void program2(void);                                               //ָ����У�������������
void program3(void);                                               //���ڲ������룬�Ҽ�����

/*
�й���������͵�����ú�����˵����
1������ĽǶ��Ǿ���λ��
2���������ģʽ�ĽǶ������λ�ã���Ϊ��ǰλ������
3����wait��Ϊ�ȴ���ɣ�����ɲ���ִ��
4��ʹ���ٶȵ��������Ʒ��򣬽Ƕ��޷���
5��......
*/

void wrmhole(void);      //�涴

void energy(void);        //ʱ������

void program1(void)     //�������
{ 
	//drop(0, 300, sp1, 100);  
	 mode = 1;
	C_D(sp1,2000,100);
    //routine6();
}

void routine1(void)    //����1���涴��ʾ
{
    mode = 1;
    
    drop(0, 300, sp1, 100);  
    C_R(sp1);
    T_R(sp1);
    
    C_R(sp1);
    T_R(sp1);
    
    C_L(sp1);
    T_L(sp1);
    C_L(sp1);
    T_L(sp1);
    C_R(sp1);
    
    T_R(sp1);
    C_D(sp1, 2000, 100); 
    
    T_A(sp2, 2850, 5);  
    
    center(sp2); 
    
    drop(132, 0, sp2, 10);  
    
    T_A(sp2, 2850, 5); 
    
    SetMagneticServoDegreeSpeed(swing, 35, 50);   
    
    drop(0, 400, sp2, 10);   
    
    drop(0, -200, sp2, 10);  
    SetMagneticServoDegreeSpeed(swing, 110, 50);
    drop(0, 130, sp2, 10);  
    
    wrmhole(); 
}

void routine2(void)    //����2����������
{
    mode = 1;
    
    drop(0, 300, sp1, 100);  
    C_R(sp1);
    T_R(sp1);
    
    C_R(sp1);
    T_R(sp1);
    
    C_L(sp1);
    T_L(sp1);
    C_L(sp1);
    T_L(sp1);
    C_R(sp1);
    
    T_R(sp1);
    C_D(sp1, 2000, 100); 
        
    C_R(sp1);
    T_R(sp1);
    
    C_L(sp1);
    T_L(sp1);
    
    C_R(sp1);
    T_R(sp1);
    C_R(sp1);
    T_R(sp1);
    C_LR(sp1);
    
    mode = 0;
    
    drop(0, 300, sp1, 100);  
    C_D(sp1, 1500, 100);   
    C_L(sp1);
    T_L(sp1);
    C_L(sp1);
    T_L(sp1);
    C_D(sp1, 620, 100); 
    C_R(sp1);
    T_R(sp1);
    C_L(sp1);
    T_L(sp1);
    C_L(sp1);
    T_L(sp1);
    C_R(sp1);
    T_R(sp1);
    C_D(sp1, 300, 100); 
    C_R(sp1);
    T_R(sp1);
    C_LR(sp1);
    
    drop(0, test1, sp2, 10);  
    SetWaitForTime(0.5); 
    drop(test2, 0, sp2, 10); 
    SetWaitForTime(0.5); 
    drop(-test2+40, 0, sp2, 10);
    SetWaitForTime(0.5); 
    drop(0, test3, sp1, 10); 
}

void routine3(void)    //����3��������ɫС��������ʱ��ת������
{
    int spx;
    int spy;
    int spz;
    long Enz;
    float bufx = 0.0;
    float bufy = 0.0;
    float bufz = 0.0;
    SetAICamLED(0);
    SetWaitForAICamData(4, 1);    //С��ʶ��0��ɫ1��ɫ2��ɫ3��ɫ
    Enz = En_z();
    while(1)
    {
        spx = GetAICamData(1);
        spy = GetAICamData(2);
        if(spx != 0 && spy != 0)
        {  
            spx = 128-spx;
            spy = spy-140;
            spz = Enz-En_z();
            if(abs(spx) < 3 && abs(spy) < 3 && abs(spz) < 3)
            {
                mydriver(0, 0, 0);
                break;
            }
            bufx = bufx+0.001*spx;
            bufy = bufy+0.001*spy;
            bufz = bufz+0.001*spz;
            if(spx == 0 || (spx > 0 && bufx < 0) || (spx < 0 && bufx > 0))
            {
                bufx = 0;
            }
            if(spy == 0 || (spy > 0 && bufy < 0) || (spy < 0 && bufy > 0))
            {
                bufy = 0;
            }
            if(spz == 0 || (spz > 0 && bufz < 0) || (spz < 0 && bufz > 0))
            {
                bufz = 0;
            }
            spx = spx;
            spy = spy+bufy;
            spz = spz+bufz;
            spx = LIMIT(spx, -20, 20);
            spy = LIMIT(spy, -20, 20);
            spz = LIMIT(spz, -20, 20);
            mydriver(spx, spy, spz);
        }
        else
        {
            mydriver(0, 0, 0);
        } 
    }
    
    drop(60, 0, sp2, 5);  
    
    drop(0, 45, sp2, 5); 
    
    energy();
    
    drop(0, -60, sp2, 5); 
}

void routine4(void)    //����4��������ɫС�������ɳ涴����
{
    int spx;
    int spy;
    int spz;
    float bufx = 0.0;
    float bufy = 0.0;
    float bufz = 0.0;
    
    long LEnx;
    long LEny;
    long LEnz;
    long tempT;
    
    SetMagneticServoDegreeSpeed(swing, 170, 50);      //150  
    
    while(1)
    {
        spx = GetAICamData(1);
        spy = GetAICamData(2);
        if(spx != 0 && spy != 0)
        {  
            spz = spx - 128;
            spx = 0;
            spy = 0;
            bufx = bufx+0.001*spx;
            bufy = bufy+0.001*spy;
            bufz = bufz+0.0002*spz;
            if(spx == 0 || (spx > 0 && bufx < 0) || (spx < 0 && bufx > 0))
            {
                bufx = 0;
            }
            if(spy == 0 || (spy > 0 && bufy < 0) || (spy < 0 && bufy > 0))
            {
                bufy = 0;
            }
            if(spz == 0 || (spz > 0 && bufz < 0) || (spz < 0 && bufz > 0))
            {
                bufz = 0;
            }
            spx = 0;
            spy = 0;
            spz = spz+bufz;
            spx = LIMIT(spx, -20, 20);
            spy = LIMIT(spy, -20, 20);
            spz = LIMIT(spz, -20, 20);
            mydriver(spx, spy, spz);
            
            if(LEnx - En_x() != 0 || LEny - En_y() != 0 || LEnz - En_z() != 0)
            {
                LEnx = En_x();
                LEny = En_y();
                LEnz = En_z();
                tempT = GetSysTime();
            }
            if(GetSysTime() - tempT > 1000)
            {
                mydriver(0, 0, 0);
                break;
            }
        
        }
        else
        {
            mydriver(0, 0, 0);
        } 
    } 
    
    SetMagneticServoDegreeSpeed(swing, 35, 50);  
    
    SetWaitForTime(1); 
    
    drop(0, 200, 20, 5);   
    
    drop(0, 500, 10, 5);
    
    drop(0, -120, 20, 5);  
    
    drop(30, 0, 20, 5); 
    
    SetMagneticServoDegreeSpeed(swing, 110, 50);  
    
    SetWaitForTime(1); 
    
    drop(0, 60, 20, 5); 
    
    wrmhole(); 
}

void routine5(void)    //����4�����õ�����ɫ��λ��ɳ涴����
{
    int spx;
    int spy;
    int spz;
    float bufx = 0.0;
    float bufy = 0.0;
    float bufz = 0.0;
    long Enz = En_z();
    long LEnx;
    long LEny;
    long LEnz;
    long tempT;
   
    while(1)
    {
        spx = GetAICamData(1);
        spy = GetAICamData(2);
        
        if(spx != 0 && spy != 0)
        {  
            spx = 160 - spx;
            spy = spy - 110;
            spz = Enz - En_z();
            
            if(abs(spx) < 2 && abs(spy) < 2 && abs(spz) < 2)
            {
                mydriver(0, 0, 0);
                break;
            }
            
            bufx = bufx+0.0002*spx;
            bufy = bufy+0.0002*spy;
            bufz = bufz+0.0002*spz;
            if(spx == 0 || (spx > 0 && bufx < 0) || (spx < 0 && bufx > 0))
            {
                bufx = 0;
            }
            if(spy == 0 || (spy > 0 && bufy < 0) || (spy < 0 && bufy > 0))
            {
                bufy = 0;
            }
            if(spz == 0 || (spz > 0 && bufz < 0) || (spz < 0 && bufz > 0))
            {
                bufz = 0;
            }
            spx = spx+bufx;
            spy = spy+bufy;
            spz = spz+bufz;
            spx = LIMIT(spx, -20, 20);
            spy = LIMIT(spy, -20, 20);
            spz = LIMIT(spz, -20, 20);
            mydriver(spx, spy, spz);
            
            if(LEnx - En_x() != 0 || LEny - En_y() != 0 || LEnz - En_z() != 0)
            {
                LEnx = En_x();
                LEny = En_y();
                LEnz = En_z();
                tempT = GetSysTime();
            }
            if(GetSysTime() - tempT > 5000)
            {
                mydriver(0, 0, 0);
                break;
            }
        
        }
        else
        {
            mydriver(0, 0, 0);
        } 
    } 
    
    drop(-45, 0, 20, 5); 
    wrmhole(); 
}

void routine6(void)    //����6����������
{ 
    mode = 1;
    
    drop(0, 300, sp1, 100);  
    C_R(sp1);
    T_R(sp1);
    
    C_R(sp1);
    T_R(sp1);
    
    C_L(sp1);
    T_L(sp1);
    C_L(sp1);
    T_L(sp1);
    C_R(sp1);
    
    T_R(sp1);
    C_D(sp1, 1700, 100);
        
    C_R(sp1);
    T_R(sp1);
    
    C_D(sp1, 650, 100);   
    T_A(sp2, 2200, 10);  
    drop(-350, 0, sp1, 100); 
    SetMagneticServoDegreeSpeed(swing, 135, 50); 
    SetAICamLED(0);
    SetWaitForAICamData(4, 0);    //С��ʶ��0��ɫ1��ɫ2��ɫ3��ɫ
    vp(160, 115);  
    drop(-45, 0, sp2, 5); 
    wrmhole(); 
    T_I(sp2, -260, 10);
    drop(250, 0, sp2, 5); 
    drop(0, 200, sp2, 100);
    
    C_L(sp1);
    T_L(sp1);
    
    C_R(sp1);
    T_R(sp1);
    C_R(sp1);
    T_R(sp1);
    C_LR(sp1);
    
    mode = 0;
    
    drop(0, 300, sp1, 100);  
    C_D(sp1, 1600, 100);   
    
    T_A(sp2, 2550, 10);  
    SetMagneticServoDegreeSpeed(swing, 135, 50); 
    SetAICamLED(0);
    SetWaitForAICamData(4, 1);    //С��ʶ��0��ɫ1��ɫ2��ɫ3��ɫ
    vp(225, 200); 
    SetMagneticServoDegreeSpeed(swing, 180, 100);
    SetWaitForTime(0.5); 
    drop(0, 30, 20, 5); 
    energy();
    drop(0, -130, sp2, 5); 
     T_I(sp2, -1200, 10);

    C_L(sp1);
    T_L(sp1);
    
    C_L(sp1);
    T_L(sp1);
    
    C_D(sp1, 620, 100); 
    
    C_R(sp1);
    T_R(sp1);
    
    C_L(sp1);
    T_L(sp1);
    
    C_L(sp1);
    T_L(sp1);
    
    C_R(sp1);
    T_R(sp1);
    
    C_D(sp1, 250, 100); 
    
    C_R(sp1);
    T_R(sp1);
    
    C_LR(sp1);
    
    drop(0, test1, sp2, 10);  
    SetWaitForTime(0.5); 
    drop(test2, 0, sp2, 10); 
    SetWaitForTime(0.5); 
    drop(-test2+40, 0, sp2, 10);
    SetWaitForTime(0.5); 
    drop(0, test3, sp1, 10); 
}

void program2(void)
{
    mxmax = -32766;
    mxmin = 32766;
    mymax = -32766;
    mymin = 32766;
    
    SetLCDClear(BLACK);
    SetFontSize(1);
    SetDisplayString(1, "���������", YELLOW, BLACK);
    SetFontSize(0);
    SetDisplayString(5, "mxmax", YELLOW, BLACK);      /*ÿ�и߶�16*/
    SetDisplayString(7, "maxmin", YELLOW, BLACK); 
    SetDisplayString(9, "mymax", YELLOW, BLACK);
    SetDisplayString(11, "mymin", YELLOW, BLACK);
    SetDisplayString(13, "ָ����", YELLOW, BLACK);
    
    while(1)
    {
        if(mxmax < compx)
        {
            mxmax = compx;          
        }
        if(mxmin > compx)
        {
            mxmin = compx;          
        }
        if(mymax < compy)
        {
            mymax = compy;          
        }
        if(mymin > compy)
        {
            mymin = compy;          
        }
        SetDisplayVariable(80, 64, mxmax, YELLOW, BLACK);
        SetDisplayVariable(80, 96, mxmin, YELLOW, BLACK);
        SetDisplayVariable(80, 128, mymax, YELLOW, BLACK);
        SetDisplayVariable(80, 160,  mymin, YELLOW, BLACK);
        SetDisplayVariable(80, 192,  yaw, YELLOW, BLACK);
        if(GetLeftButton() || GetRightButton() )
        {
		T_I(sp2,3600,10);
        }
        if(GetTouchScreen())
        {
		SetData(120,mxmax-300);
		SetData(121,mxmin -300);
		SetData(122,mymax*-1);
		SetData(123,mymin*-1);
		if(mxmax-300<0)
		{
		SetData(124,0207);
		}
		
            break;
        }
    }
    while(1);
}

void program3(void)
{
    unsigned char count1;        
    unsigned char count2;     
    mode = 0;   
    SetWaitForTime(0.1); 
    count1 = count;
    mode = 1;   
    SetWaitForTime(0.1); 
    count2 = count;
    if(count1 < count2)
    {
        mode = 0; 
    }
    else
    {
        mode = 1; 
    }
    SetWaitForTime(0.1); 
    
    while(1)
    {
        curve(sp1);  
        if(GetTouchScreen())
        {
            break;
        }
    }
}

void task1(void)
{
    start();
    stop();
}

void task2(void)
{
    while(1)
    {
        pd();
        compx = GetAHRS(ahrs, 10, 1);                  //x10
        compy = (int)GetAHRS(ahrs, 12, 1);           //y11
        compz = (int)GetAHRS(ahrs, 11, 1);           //z12
        yaw = comp();
    }
}

void start(void)
{
    E6RCU_Init();
    
    sp1 = GetData(1);
    sp2 = GetData(2);
    test1 = GetData(3);
    test2 = GetData(4);
    test3 = GetData(5);
    test4 = GetData(6);
    test5 = GetData(7);
    test6 = GetData(8);
    test7 = GetData(9);
    
    if( GetData(120) != 0 && GetData(121) !=0 && GetData(122) !=0 && GetData(123) !=0)
    {
	mxmax =  GetData(120)+300;
	mxmin = GetData(121)+300;
	mymax = GetData(122)*-1;
	mymin = GetData(123)*-1;
	
    }
    
    /*pid��������*/
    pidgray.kp = 5.0;
    pidgray.ki = 0.002;
    pidgray.kd = 10.0;
    
    pidEnt.kp = 1.0;
    pidEnt.ki = 0.001;
    pidEnt.kd = 10.0;
    
    pidaround.kp = 5.0;
    pidaround.ki = 0.001;
    pidaround.kd = 10.0;
    
    /*pid��ʼ��*/
    pidgray.integ = 0.0;
    pidgray.prevError = 0.0;
    pidgray.pidout = 0.0;
    
    pidEnt.integ = 0.0;
    pidEnt.prevError = 0.0;
    pidEnt.pidout = 0.0;
    
    pidaround.integ = 0.0;
    pidaround.prevError = 0.0;
    pidaround.pidout = 0.0;
    
    SetTraceV2BeepI2C(trace, 1);
    
    SetFontSize(1);
    SetDisplayString(1, "���������", YELLOW, BLACK);
    SetFontSize(0);
    SetDisplayString(5, "�Ҷ�ͨ��", YELLOW, BLACK);      /*ÿ�и߶�16*/
    SetDisplayString(7, "����X", YELLOW, BLACK); 
    SetDisplayString(9, "����Y", YELLOW, BLACK); 
    SetDisplayString(11, "�����", YELLOW, BLACK);
    SetDisplayString(13, "ָ����", YELLOW, BLACK);
    SetDisplayString(15, "ʱ��", YELLOW, BLACK);
    
    while(1)
    {
        SetDisplayVariable(80, 64, SL, YELLOW, BLACK);
        SetDisplayVariable(80, 96, En_x(), YELLOW, BLACK);
        SetDisplayVariable(80, 128, En_y(), YELLOW, BLACK);
        SetDisplayVariable(80, 160, En_z(), YELLOW, BLACK);
        SetDisplayVariable(80, 192,  yaw, YELLOW, BLACK);
        SetDisplayVariable(80, 224, GetSysTime(), YELLOW, BLACK);
        
        if ( GetTouchScreen() )
        {
            En0();
            SetSysTime();
            program1();
            break;
        }
        else if ( GetLeftButton() )
        {
            En0();
            SetSysTime();
            program2();
            break;
        }
        else if ( GetRightButton() )
        {
            En0();
            SetSysTime();
            program3();
            break;
        }
    }
}

void stop(void)
{
    unsigned long  Tend;
    Tend =  GetSysTime();
    mydriver(0, 0, 0);
    SetDisplayVariable(80, 64, SL, YELLOW, BLACK);
    SetDisplayVariable(80, 96, En_x(), YELLOW, BLACK);
    SetDisplayVariable(80, 128, En_y(), YELLOW, BLACK);
    SetDisplayVariable(80, 160, En_z(), YELLOW, BLACK);
    SetDisplayVariable(80, 192,  yaw, YELLOW, BLACK);
    SetDisplayVariable(80, 224, GetSysTime(), YELLOW, BLACK);
    while(1);
}                                     

long En_x(void)
{
    return (long)((GetMotorCode(fl)-GetMotorCode(fr)-GetMotorCode(bl)+GetMotorCode(br))/lcx);
}

long En_y(void)
{
    return (long)((GetMotorCode(fl)+GetMotorCode(fr)+GetMotorCode(bl)+GetMotorCode(br))/lcy);
}

long En_z(void)
{
    return (long)((-GetMotorCode(fl)+GetMotorCode(fr)-GetMotorCode(bl)+GetMotorCode(br))/ac);
}

void En0(void)
{
    SetMotorCode(fl);
    SetMotorCode(fr);
    SetMotorCode(bl);
    SetMotorCode(br);
}

int comp(void)
{
    int16_t degree;
    static double mx;
    static double my;
    double angle; 
    int16_t offsetX;
    int16_t offsetY;
    offsetX = (mxmax+mxmin)/2;
    offsetY = (mymax+mymin)/2;
    mx = 0.85*mx+0.15*compx;
    my = 0.85*my+0.15*compy;
    angle = atan2(my-offsetY, mx-offsetX);
    angle = 572.958*angle;
    degree = (int16_t)angle;	
    degree = (3600-degree)%3600;	
    degree = (degree-comp0+3600)%3600;	
    return 3599-degree;
}

void camtest(int cmd1, int cmd2)
{
    SetAICamLED(0);
    SetWaitForAICamData(cmd1, cmd2);    //С��ʶ��0��ɫ1��ɫ2��ɫ3��ɫ
    SetLCDClear(BLACK);
    while(1)
    {
        SetDisplayVariable(80, 10, GetAICamData(1), YELLOW, BLACK);
        SetDisplayVariable(80, 30, GetAICamData(2), YELLOW, BLACK);
        SetDisplayVariable(80, 50, GetAICamData(3), YELLOW, BLACK);
        SetDisplayVariable(80, 70, GetAICamData(4), YELLOW, BLACK);
        SetDisplayVariable(80, 90, GetAICamData(5), YELLOW, BLACK);
        SetDisplayVariable(80, 110, GetAICamData(6), YELLOW, BLACK);
        SetDisplayVariable(80, 130, GetAICamData(7), YELLOW, BLACK);
        SetDisplayVariable(80, 150, GetAICamData(8), YELLOW, BLACK);
        SetDisplayVariable(80, 170, GetAICamData(9), YELLOW, BLACK);
        SetDisplayVariable(80, 190, GetAICamData(10), YELLOW, BLACK);
        SetDisplayVariable(80, 210, GetAICamData(11), YELLOW, BLACK);
        SetDisplayVariable(80, 230, GetAICamData(12), YELLOW, BLACK);
        SetDisplayVariable(80, 250, GetAICamData(13), YELLOW, BLACK);
        SetDisplayVariable(80, 270, GetAICamData(14), YELLOW, BLACK);
    }
}

void vp(int x, int y)    
{
    int spx;
    int spy;
    int spz;
    float bufx = 0.0;
    float bufy = 0.0;
    float bufz = 0.0;
    long Enz = En_z();
    long LEnx;
    long LEny;
    long LEnz;
    long tempT;
   
    while(1)
    {
        spx = GetAICamData(1);
        spy = GetAICamData(2);
        if(spx != 0 && spy != 0)
        {  
            spx = x - spx;
            spy = spy - y;
            spz = Enz - En_z();
            
            if(abs(spx) < 3 && abs(spy) < 3 && abs(spz) < 3)
            {
                mydriver(0, 0, 0);
                break;
            }
            
            bufx = bufx+0.0001*spx;
            bufy = bufy+0.0001*spy;
            bufz = bufz+0.0001*spz;
            
            if(spx == 0 || (spx > 0 && bufx < 0) || (spx < 0 && bufx > 0))
            {
                bufx = 0;
            }
            if(spy == 0 || (spy > 0 && bufy < 0) || (spy < 0 && bufy > 0))
            {
                bufy = 0;
            }
            if(spz == 0 || (spz > 0 && bufz < 0) || (spz < 0 && bufz > 0))
            {
                bufz = 0;
            }
            
            spx = spx+bufx;
            spy = spy+bufy;
            spz = spz+bufz;
            spx = LIMIT(spx, -20, 20);
            spy = LIMIT(spy, -20, 20);
            spz = LIMIT(spz, -20, 20);
            mydriver(spx, spy, spz);
            
            if(LEnx - En_x() != 0 || LEny - En_y() != 0 || LEnz - En_z() != 0)
            {
                LEnx = En_x();
                LEny = En_y();
                LEnz = En_z();
                tempT = GetSysTime();
            }
            if(GetSysTime() - tempT > 5000)
            {
                mydriver(0, 0, spz);
                break;
            }
        }
        else
        {
            mydriver(0, 0, 0);
        } 
    } 
}

int angle_d(int angle)
{
    int degree;
    degree = angle-yaw;     
    if(degree > 1800)
    {
	degree = degree-3600;
    }
    else if(degree < -1800)
    {
	degree = degree+3600;
    }
    return degree;
}

void mydriver(int spx, int spy, int turn)
{
    int speed1;
    int speed2;
    int speed3;
    int speed4;
    speed1 = spy+spx-turn;
    speed2 = spy-spx+turn;
    speed3 = spy-spx-turn;
    speed4 = spy+spx+turn;
    speed1 = LIMIT(speed1, -100, 100); 
    speed2 = LIMIT(speed2, -100, 100); 
    speed3 = LIMIT(speed3, -100, 100); 
    speed4 = LIMIT(speed4, -100, 100); 
    SetMotor(fl, speed1);
    SetMotor(fr, speed2);
    SetMotor(bl, speed3);
    SetMotor(br, speed4);
}

void drop(int x, int y, int speed, int error)
{
    int spx;
    int spy;
    int spz;
    long Enx;
    long Eny;
    long Enz;
    long LEnx;
    long LEny;
    long LEnz;
    long tempT;
    Enx = En_x();
    Eny = En_y();
    Enz = En_z();
    while(1)
    {
        spx = x+Enx-En_x();
        spy = y+Eny-En_y();
        spz = Enz-En_z();
        if(abs(spx) < error && abs(spy) < error)
        {
            mydriver(0, 0, 0);
            break;
        }

        spx = LIMIT(5*spx, -speed, speed); 
        spy = LIMIT(5*spy, -speed, speed); 
        spz = LIMIT(5*spz, -speed, speed); 
        mydriver(spx, spy, spz);
        
        if(LEnx - En_x() != 0 || LEny - En_y() != 0 || LEnz - En_z() != 0)
        {
            LEnx = En_x();
            LEny = En_y();
            LEnz = En_z();
            tempT = GetSysTime();
        }
        if(GetSysTime() - tempT > 1000)
        {
            mydriver(0, 0, 0);
            break;
        }
    }
}

void curve(int speed)
{
    int spx;
    int spy;
    int spz;
    if(pidgray.desired != SL)
    {
        pidgray.integ = 0.0;
        SL_Ent = En_z();
        pidgray.desired = SL;
        pidgray.measured = 0;
    }
    pidUpdate(&pidgray);
    
    spx = 0;
    
    spy = (int)(speed*(1-0.06*abs(SL)));  
        
    spz = (int)(0.3*speed*SL);  
    
    //spz = (int)(pidgray.pidout);  
    
    if(spz > 0)
    {
        spz =  LIMIT(spz - (En_z() - SL_Ent), spz/2, 200);   
    }
    else if(spz < 0)
    {
        spz =  LIMIT(spz - (En_z() - SL_Ent), -200, spz/2);    
    }
   
    mydriver(spx, spy, spz);
}

void center(int speed)
{
    int spx;
    int spy;
    int spz;
    long Enx;
    long Eny;
    long Enz;
    long tempT = GetSysTime();
    Enx = En_x();
    Eny = En_y();
    Enz = En_z();
    while(1)
    {
        pidgray.desired = SL;
        pidgray.measured = 0;
        pidUpdate(&pidgray);
    
        spx = (int)(-1*pidgray.pidout);  
    
        spy = Eny-En_y(); 
    
        spz = Enz-En_z();  
    
        spx =  LIMIT(spx, -speed, speed); 
   
        mydriver(spx, spy, spz);
        
        if(SL == 0)
        {
            mydriver(0, 0, 0);
            if(GetSysTime() - tempT > 200)
            {
                break;
            } 
        }
        else
        {
            tempT = GetSysTime();
        }   
    }
}

int getBit(unsigned int ch, unsigned char bit)
{
    return   ch   &   (0x01   <<   bit)   ?   1   :   0;   
}

void pd(void)
{
    unsigned int i;
    unsigned int data;
    
    data = GetTraceV2I2C(trace, 9);
    
    for(i = 0; i < 7; i++)
    {
        S0[i] = getBit(data, i);
    }
    
    count = 0;
    if(mode)
    {
        for(i = 0; i < 7; i++)
        {
            S[i] = !S0[i];
            count = count + S[i];
        }
    }
    else
    {
        for(i = 0; i < 7; i++)
        {
            S[i] = S0[i];
            count = count + S[i];
        }
    }

    if(S[2] && S[3] && S[4])
    {
        SL = 0;
    }
    else if(S[2] && S[3])
    {
        SL = 1;
    }
    else if(S[3] && S[4])
    {
        SL = -1;
    }
    else if(S[3])
    {
        SL = 0;
    }
    else if(S[1] && S[2])
    {
        SL = 3;
    }
    else if(S[4] && S[5])
    {
        SL = -3;
    }
    else if(S[2])
    {
        SL = 2;
    }
    else if(S[4])
    {
        SL = -2;
    } 
    else if(S[0] && S[1])
    {
        SL = 5;
    }
    else if(S[5] && S[6])
    {
        SL = -5;
    }
    else if(S[1])
    {
        SL = 4;
    }
    else if(S[5])
    {
        SL = -4;
    }
    else if(S[0])
    {
        SL = 6;
    }
    else if(S[6])
    {
        SL = -6;
    }
}

void C_D(int speed, long dist, int error)
{
    int move;
    long t;
    long tempEny;
    tempEny = En_y();
    t = GetSysTime();
    while(1)
    {
        move = (int)(dist - (En_y() - tempEny));
        if(abs(move) <= error)
        {
            if(GetSysTime() - t > 200)
            {
                mydriver(0, 0, 0);
                break;
            }
        }
        else
        {
            t = GetSysTime();
        }
        move = LIMIT(5*move, -abs(speed), abs(speed)); 
        curve(move);   
    }
}

void C_L(int speed)
{
    while(1)
    {
        curve(speed); 
        if(!S[0])
        {
            break;
        }
    }
    while(1)
    {
        curve(speed); 
        if(S[0])
        {
            break;
        }
    }
}

void C_R(int speed)
{
    while(1)
    {
        curve(speed);  
        if(!S[6])
        {
            break;
        }
    }
    while(1)
    {
        curve(speed); 
        if(S[6])
        {
            break;
        }
    }
}

void C_A(int speed, int angle, int error)
{
    int dg;
    while(1)
    {
        curve(speed); 
        dg = angle_d(angle);
        if(abs(dg) < error)
        {
            mydriver(0, 0, 0);
            break;
        }
    }
}

void C_LR(int speed)                 
{
    while(1)
    {
        curve(speed); 
        if(count == 7)                                     
        {
            mydriver(0, 0, 0);
            break;
        }
    }
}

void C_B(int speed)                 
{
    while(1)
    {
        curve(speed); 
        if(count == 0 || count == 7)                                     
        {
            break;
        }
    }
}

void T_L(int speed)
{
    while(1)
    { 
        curve(speed); 
        if(!S[0] && !S[1])  
        {
            break;
        }
    } 
    while(1)
    { 
        mydriver(0, 0, speed);
        if(S[1])  
        {
            break;
        }
    }
}

void T_R(int speed)
{
    while(1)
    { 
        curve(speed); 
        if(!S[5] && !S[6])   
        {
            break;
        }
    }
    while(1)
    { 
        mydriver(0, 0, -speed);  
        if(S[5])  
        {
            break;
        }
    }
}

void T_I(int speed, int angle, int error)
{
    int spx;
    int spy;
    int spz;
    long tempEnx;
    long tempEny;
    long tempEnz;
    long tempT;
    tempEnx = En_x();
    tempEny = En_y();
    tempEnz = En_z();
    tempT = GetSysTime();
    while(1)
    {
        spx = (int)(tempEnx-En_x());
        spy = (int)(tempEny-En_y());
        spz = (int)(angle+tempEnz-En_z());
        if(abs(spz) < error)
        {
            if(GetSysTime() - tempT > 200)
            {
                mydriver(0, 0, 0);  
                break;
            }
        }
        else
        {
            tempT = GetSysTime();
        }
        spx = 5*spx;
        spy = 5*spy;
        spz = 5*spz;
        spx = LIMIT(spx, -abs(speed), abs(speed));                                
        spy = LIMIT(spy, -abs(speed), abs(speed));  
        spz = LIMIT(spz, -abs(speed), abs(speed));  
        mydriver(spx, spy, spz);  
    }
} 

void T_A(int speed, int angle, int error)
{
    int dg;
    long tempT;
    tempT = GetSysTime();
    while(1)
    {
        SetWaitForTime(0.1); 
        dg = angle_d(angle);
        T_I(speed, dg, error);
        if(abs(dg) < error)
        {
            mydriver(0, 0, 0);
            break;
        }
    }
}

void alignment(void)
{
    int spx;
    int spy;
    int spz;
    float bufy = 0;
    float bufz = 0;
    long Enx = En_x();
    long time = GetSysTime();
    while(1)
    {
        if(count == 0 || count == 7)  
        spx = Enx-En_x();
        spy = 3-S[0]-S[1]-S[2]-S[4]-S[5]-S[6];
        spz = S[0]+S[1]+S[2]-S[4]-S[5]-S[6];
        if(abs(spy) < 1 && abs(spz) < 1)
        {
            if(GetSysTime() - time > 250)
            {
                mydriver(0, 0, 0);  
                break;
            }
        }
        else
        {
           time = GetSysTime();
        }
        bufy = bufy+0.001*spy;
        bufz = bufz+0.001*spz;
        if(spy == 0 || (spy > 0 && bufy < 0) || (spy < 0 && bufy > 0))
        {
            bufy = 0;
        }
        if(spz == 0 || (spz > 0 && bufz < 0) || (spz < 0 && bufz > 0))
        {
            bufz = 0;
        }
        spx = 3*spx;
        spy = 3*spy+bufy;
        spz = 3*spz+bufz;
        spx = LIMIT(spx, -30, 30);
        spy = LIMIT(spy, -30, 30);
        spz = LIMIT(spz, -30, 30);
        mydriver(spx, spy, spz);
    }
}

void wrmhole(void)
{
    for(int i = 0; i < 17; i++)
    {  
        SetWaitForTime(0.5);
        SetMagneticServoDegreeSpeed(swing, 70, 25);          //������ֿ�����������Կ���ʹ����ʱ�˳��ķ�ʽ
        SetWaitForTime(0.5);
        SetMagneticServoDegreeSpeed(swing, 110, 25);        
    }
    SetMagneticServoDegreeSpeed(swing, 180, 50);
}

void energy(void)
{
    SetMagneticServoCodeMotor(rotate, 8.03*4096, 100);        //תһȦΪ4096����Ҫת��41Ȧ
}

void pidUpdate(PidObject* pid)
{
    float error;  
	 
    error = pid->desired - (pid->measured); 

    pid->integ += error;	
    
    if(error == 0.0f || (error > 0.0f && pid->integ < 0.0f) || (error < 0.0f && pid->integ > 0.0f))
    {
        pid->integ = 0.0f;
    }

    pid->deriv = error - pid->prevError;  
	
    pid->pidout = pid->kp * error + pid->ki * pid->integ + pid->kd * pid->deriv;
		
    pid->prevError = error;  
}
